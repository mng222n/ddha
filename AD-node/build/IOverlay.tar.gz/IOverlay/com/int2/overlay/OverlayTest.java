/**
 * Test Overlay API
 */
package com.int2.overlay;

import java.util.List;
import java.util.ListIterator;
	
import com.int2.overlay.IOverlay;
//import com.int2.expeshare.p2psiphoc.Constants;


/**
 * @author INT
 *
 */
public class OverlayTest {

	/**
	 * @param args
	 */
	
	public OverlayTest(){
		
	}
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		IOverlay iover = new IOverlayImpl();
		//set gateway
		iover.setGateway("157.159.228.7", 3631);
		
		//put
		//String uri = "bob@123.123.123.123:1342";
		//String[] strArr = new String[2];
		//strArr = Constants.getTarget(uri);
		//System.out.println("uri: " + uri);
		//System.out.println("user: " + strArr[0] );
		//System.out.println("ip: " + strArr[1] );
		
		//int ret = iover.put(strArr[0], strArr[1], new Integer(3600) );
		int ret = iover.put("bibo", "192.168.1.1", new Integer(3600) );
		if (ret < 0 )
			System.out.println("Put fail");
		else
			System.out.println("Put succeed");
		
		//get
		List<String> lines;
		lines = iover.get("honey", new Integer(10) );
		if (lines == null)
			System.out.println("Get fail");
		else
			System.out.println("Get succeed");
		
		//return values
		if (lines != null ) {
		
			ListIterator<String> li = lines.listIterator();
			String line = null;
			
			while (li.hasNext()) {
				line = (String)li.next();
				System.out.println( line );
			}
		}
	}

}
