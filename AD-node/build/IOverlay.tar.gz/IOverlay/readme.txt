#
# API in order to access into INT's DHT Overlay
#
# Check the directory for more details
#
# (C)2008 - INT
#

doc/ 					- Javadoc references for IOverlay API

lib/IOverlay.jar 			- Main library has been packaged
lib/xmlrpc-1.2-b1.jar 			- XML-RPC library has been included

com/int2/overlay/IOverlay.java 		- Source code of IOverlay API Interface
com/int2/overlay/IOverlayImpl.java 		- Source code of IOverlay API Implemented
com/int2/overlay/OverlayTest.java 	- An example how to use IOverlay API

manifest.mf 				- MANIFEST file for making .jar (jar -cvfm IOverlay.jar manifest.mf com)

---
Test it:
java -jar IOverlay.jar